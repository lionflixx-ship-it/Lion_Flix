package com.lionflix.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.*
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var out: OutputStream? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.addJavascriptInterface(Bridge(), "Android")
        // Faz as requisições de lista e streams passarem pelo app, sem bloqueio de CORS
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url
                val host = u.host ?: return null
                if (u.scheme != "http" && u.scheme != "https") return null
                if (host.endsWith("cloudflare.com") || host.endsWith("googleapis.com") || host.endsWith("gstatic.com")) return null
                return try {
                    val c = URL(u.toString()).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000
                    c.readTimeout = 60000
                    r.requestHeaders.forEach { (k, v2) ->
                        if (k.equals("Range", true) || k.equals("User-Agent", true)) c.setRequestProperty(k, v2)
                    }
                    val code = c.responseCode
                    val h = HashMap<String, String>()
                    h["Access-Control-Allow-Origin"] = "*"
                    listOf("Content-Range", "Accept-Ranges").forEach { n -> c.getHeaderField(n)?.let { h[n] = it } }
                    val mime = c.contentType?.substringBefore(';') ?: "application/octet-stream"
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    WebResourceResponse(mime, null, code, c.responseMessage ?: "OK", h, stream)
                } catch (e: Exception) { null }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                startActivityForResult(p.createIntent(), 1)
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 1) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); chooser = null }
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        @JavascriptInterface fun saveStart(name: String, mime: String) {
            out?.close()
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LionFlix")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            out = contentResolver.openOutputStream(uri)
        }
        @JavascriptInterface fun saveChunk(b64: String) { out?.write(Base64.decode(b64, Base64.DEFAULT)) }
        @JavascriptInterface fun saveEnd() { out?.close(); out = null }
    }
}
