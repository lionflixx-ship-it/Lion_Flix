plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}

// Mostra os erros do Kotlin como avisos na primeira tela do GitHub (Summary)
val lionErros = object : org.gradle.api.logging.StandardOutputListener {
    override fun onOutput(output: CharSequence) {
        val s = output.toString().trimStart()
        if (s.startsWith("e: ")) {
            println("::error::" + s.trim().replace("\n", " ").take(500))
        }
    }
}
logging.addStandardErrorListener(lionErros)
logging.addStandardOutputListener(lionErros)
