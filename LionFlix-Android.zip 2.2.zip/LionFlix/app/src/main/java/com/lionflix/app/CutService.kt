package com.lionflix.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.util.Base64
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.util.concurrent.Executors

class CutPart(val n: Int, val uri: String, val thumb: String)

object CutState {
    @Volatile var running = false
    @Volatile var cancel = false
    @Volatile var total = 0
    @Volatile var pct = 0
    @Volatile var msg = ""
    @Volatile var error = ""
    val parts = ArrayList<CutPart>()
}

const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

class CutService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var wl: PowerManager.WakeLock? = null
    private var tr: Transformer? = null
    private var url = ""
    private var base = ""
    private var folder = ""
    private var fill = false
    private var lenMs = 60000L
    private var durMs = 0L
    private var partMs = 0L
    private var n = 0
    private var k = 0
    private val out by lazy { File(cacheDir, "parte.mp4") }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val it2 = i ?: return START_NOT_STICKY
        if (it2.action == "cancel") {
            CutState.cancel = true
            tr?.cancel()
            finishAll("Cortes cancelados")
            return START_NOT_STICKY
        }
        url = it2.getStringExtra("url") ?: return START_NOT_STICKY
        base = it2.getStringExtra("name") ?: "Filme"
        folder = base.replace(Regex("[^\\p{L}\\p{N} ._()-]"), "").trim().ifEmpty { "Filme" }
        fill = it2.getStringExtra("mode") == "fill"
        lenMs = it2.getIntExtra("len", 60) * 1000L
        System.setProperty("http.agent", UA)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cortes", "Cortes", NotificationManager.IMPORTANCE_LOW))
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lionflix:cut").also { it.acquire(6 * 3600 * 1000L) }
        startForeground(1, notif("Preparando os cortes...", -1, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        CutState.msg = "Lendo o filme..."
        io.execute {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(url, hashMapOf("User-Agent" to UA))
                durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
                r.release()
                n = Math.max(1, Math.ceil(durMs / lenMs.toDouble()).toInt())
                partMs = durMs / n
                CutState.total = n
                k = 0
                main.post { next() }
            } catch (e: Exception) {
                main.post { fail("Não foi possível abrir o filme: " + e.message) }
            }
        }
        return START_NOT_STICKY
    }

    private fun notif(text: String, pct: Int, ongoing: Boolean): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "cortes")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("LionFlix")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(ongoing)
            .setProgress(100, Math.max(pct, 0), pct < 0)
            .build()
    }

    private fun next() {
        if (CutState.cancel) return
        if (k >= n) finishAll("Pronto: " + n + " partes salvas em Downloads/LionFlix") else startPart()
    }

    private fun startPart() {
        val s = k * partMs
        val e = if (k == n - 1) durMs else s + partMs
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s).setEndPositionMs(e).build()
        val item = MediaItem.Builder().setUri(url).setClippingConfiguration(clip).build()
        val layout = if (fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
        val ov = OverlayEffect(ImmutableList.of<TextureOverlay>(BitmapOverlay.createStaticBitmapOverlay(labelBmp(k + 1))))
        val fx = Effects(emptyList<AudioProcessor>(), listOf<Effect>(Presentation.createForWidthAndHeight(720, 1280, layout), ov))
        val edited = EditedMediaItem.Builder(item).setEffects(fx).build()
        out.delete()
        CutState.pct = 0
        CutState.msg = "Cortando a parte " + (k + 1) + " de " + n
        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(
                DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(3500000).build())
                    .build()
            )
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) { partDone() }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    main.post { fail("Erro na parte " + (k + 1) + ": " + exportException.message) }
                }
            }).build()
        tr = t
        t.start(edited, out.absolutePath)
        main.removeCallbacks(pollTask)
        main.postDelayed(pollTask, 700)
    }

    private val pollTask = object : Runnable {
        override fun run() {
            val t = tr ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) CutState.pct = h.progress
            val all = (k * 100 + CutState.pct) / Math.max(n, 1)
            getSystemService(NotificationManager::class.java)
                .notify(1, notif("Parte " + (k + 1) + " de " + n, all, true))
            main.postDelayed(this, 700)
        }
    }

    private fun partDone() {
        main.removeCallbacks(pollTask)
        val idx = k + 1
        io.execute {
            try {
                val pad = idx.toString().padStart(2, '0')
                val uri = saveFile("$folder - Parte $pad.mp4", "video/mp4") { o -> out.inputStream().use { it.copyTo(o) } }
                var thumb = ""
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(out.absolutePath)
                    val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 2000L
                    val f = r.getFrameAtTime(d * 500, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (f != null) {
                        val cv = Bitmap.createScaledBitmap(f, 1080, 1920, true)
                        saveFile("$folder - Parte $pad capa.jpg", "image/jpeg") { o -> cv.compress(Bitmap.CompressFormat.JPEG, 90, o) }
                        val th = Bitmap.createScaledBitmap(cv, 180, 320, true)
                        val bo = ByteArrayOutputStream()
                        th.compress(Bitmap.CompressFormat.JPEG, 70, bo)
                        thumb = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                    }
                } catch (e: Exception) {
                } finally {
                    r.release()
                }
                synchronized(CutState.parts) { CutState.parts.add(CutPart(idx, uri.toString(), thumb)) }
                main.post { k++; next() }
            } catch (e: Exception) {
                main.post { fail("Erro ao salvar a parte " + idx + ": " + e.message) }
            }
        }
    }

    private fun saveFile(name: String, mime: String, w: (OutputStream) -> Unit): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LionFlix/" + folder)
        }
        val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(u)!!.use { w(it) }
        return u
    }

    private fun labelBmp(num: Int): Bitmap {
        val b = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        try {
            val logo = assets.open("logo_overlay.png").use { BitmapFactory.decodeStream(it) }
            if (logo != null) {
                val l = Bitmap.createScaledBitmap(logo, 260, 260, true)
                c.drawBitmap(l, 230f, 40f, p)
            }
        } catch (e: Exception) {
        }
        val t = "PARTE $num"
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.textSize = 90f
        val tw = p.measureText(t)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 12f
        p.color = 0xFF000000.toInt()
        c.drawText(t, (720 - tw) / 2, 1140f, p)
        p.style = Paint.Style.FILL
        p.color = 0xFFFFB21E.toInt()
        c.drawText(t, (720 - tw) / 2, 1140f, p)
        return b
    }

    private fun fail(m: String) {
        CutState.error = m
        finishAll(m)
    }

    private fun finishAll(m: String) {
        main.removeCallbacks(pollTask)
        CutState.msg = m
        CutState.running = false
        wl?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java).notify(2, notif(m, 0, false))
        stopSelf()
    }
}
