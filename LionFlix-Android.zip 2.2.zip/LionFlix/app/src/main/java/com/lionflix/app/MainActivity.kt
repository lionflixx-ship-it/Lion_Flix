package com.lionflix.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object ListState {
    @Volatile var state = "idle"
    @Volatile var bytes = 0L
    @Volatile var total = -1L
    @Volatile var msg = ""
    @Volatile var gen = 0
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var out: OutputStream? = null
    private var rd: BufferedReader? = null
    private var lw: java.io.Writer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        web = WebView(this)
        setContentView(web)
        Thread {
            val fs = imgDir.listFiles() ?: return@Thread
            if (fs.size > 6000) fs.sortedBy { it.lastModified() }.take(fs.size / 2).forEach { it.delete() }
        }.start()
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url
                val host = u.host ?: return null
                if (u.scheme != "http" && u.scheme != "https") return null
                if (host.endsWith("cloudflare.com") || host.endsWith("googleapis.com") || host.endsWith("gstatic.com")) return null
                val pth = (u.path ?: "").lowercase()
                val isImg = pth.endsWith(".jpg") || pth.endsWith(".jpeg") || pth.endsWith(".png") || pth.endsWith(".webp") || pth.endsWith(".gif") || (r.requestHeaders["Accept"] ?: "").contains("image/")
                if (isImg) return imageResponse(u.toString())
                if (pth.contains("/movie/") || pth.contains("/series/") || pth.endsWith(".mp4") || pth.endsWith(".mkv") || pth.endsWith(".avi") || pth.endsWith(".mov") || pth.endsWith(".webm")) return null
                return try {
                    val c = URL(u.toString()).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000
                    c.readTimeout = 60000
                    r.requestHeaders.forEach { (k, v2) ->
                        if (k.equals("Range", true) || k.equals("User-Agent", true)) c.setRequestProperty(k, v2)
                    }
                    val code = c.responseCode
                    val h = HashMap<String, String>()
                    h["Access-Control-Allow-Origin"] = "*"
                    listOf("Content-Range", "Accept-Ranges").forEach { n -> c.getHeaderField(n)?.let { h[n] = it } }
                    val mime = c.contentType?.substringBefore(';') ?: "application/octet-stream"
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    WebResourceResponse(mime, null, code, c.responseMessage ?: "OK", h, stream)
                } catch (e: Exception) { null }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                startActivityForResult(p.createIntent(), 1)
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    private val imgDir by lazy { File(cacheDir, "img").also { it.mkdirs() } }

    private fun md5(s: String): String =
        java.security.MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun imageResponse(url: String): WebResourceResponse? {
        return try {
            val f = File(imgDir, md5(url))
            if (!f.exists()) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                c.setRequestProperty("User-Agent", UA)
                if (c.responseCode != 200) return null
                val data = c.inputStream.use { it.readBytes() }
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(data, 0, data.size, o)
                var sm = 1
                while (o.outWidth / (sm * 2) >= 400) sm *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = sm
                val bm = BitmapFactory.decodeByteArray(data, 0, data.size, o2) ?: return null
                f.outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                bm.recycle()
            }
            WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), f.inputStream())
        } catch (e: Exception) {
            null
        }
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 1) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); chooser = null }
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        // ---- lista M3U salva no aparelho ----
        @JavascriptInterface fun hasList(): Boolean = File(filesDir, "list.m3u").exists()

        @JavascriptInterface fun getCred(): String = getSharedPreferences("lf", 0).getString("cred", "") ?: ""

        @JavascriptInterface fun saveCred(j: String) { getSharedPreferences("lf", 0).edit().putString("cred", j).apply() }

        @JavascriptInterface fun clearCred() { getSharedPreferences("lf", 0).edit().remove("cred").apply() }

        @JavascriptInterface fun listAgeMin(): Long {
            val f = File(filesDir, "list.m3u")
            return if (f.exists()) (System.currentTimeMillis() - f.lastModified()) / 60000 else -1
        }

        @JavascriptInterface fun saveListStart() { lw?.close(); lw = File(filesDir, "list.part").bufferedWriter() }

        @JavascriptInterface fun saveListChunk(t: String) { lw?.write(t) }

        @JavascriptInterface fun saveListEnd() {
            lw?.close()
            lw = null
            ListState.gen += 1
            val p = File(filesDir, "list.part")
            if (p.exists()) p.renameTo(File(filesDir, "list.m3u"))
        }

        @JavascriptInterface fun clearList() {
            getSharedPreferences("lf", 0).edit().remove("cred").apply()
            ListState.gen += 1
            rd?.close()
            rd = null
            File(filesDir, "list.m3u").delete()
            File(filesDir, "list.tmp").delete()
            ListState.state = "idle"
        }

        @JavascriptInterface fun loadList(dns: String, user: String, pass: String) {
            ListState.state = "downloading"; ListState.bytes = 0; ListState.total = -1; ListState.msg = ""
            ListState.gen += 1
            val my = ListState.gen
            Thread {
                try {
                    var d = dns.trim().trimEnd('/')
                    if (!d.startsWith("http")) d = "http://$d"
                    val q = "/get.php?username=" + URLEncoder.encode(user, "UTF-8") + "&password=" +
                        URLEncoder.encode(pass, "UTF-8") + "&type=m3u_plus&output=hls"
                    val c = URL(d + q).openConnection() as HttpURLConnection
                    c.setRequestProperty("User-Agent", UA)
                    c.connectTimeout = 20000
                    c.readTimeout = 60000
                    if (c.responseCode != 200) throw Exception("Servidor respondeu " + c.responseCode)
                    ListState.total = c.contentLengthLong
                    val tmp = File(filesDir, "list.tmp")
                    c.inputStream.use { i ->
                        tmp.outputStream().use { o ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val r = i.read(buf)
                                if (r < 0) break
                                o.write(buf, 0, r)
                                ListState.bytes += r
                            }
                        }
                    }
                    val head = tmp.bufferedReader().use { val cb = CharArray(300); val r2 = it.read(cb); if (r2 > 0) String(cb, 0, r2) else "" }
                    if (!head.contains("#EXTM3U") && !head.contains("#EXTINF")) throw Exception("Resposta inválida. Confira DNS, usuário e senha.")
                    if (my != ListState.gen) { tmp.delete(); ListState.state = "idle"; return@Thread }
                    tmp.renameTo(File(filesDir, "list.m3u"))
                    ListState.state = "done"
                } catch (e: Exception) {
                    ListState.msg = e.message ?: "erro"
                    ListState.state = "error"
                }
            }.start()
        }

        @JavascriptInterface fun listStatus(): String =
            JSONObject().put("state", ListState.state).put("bytes", ListState.bytes)
                .put("total", ListState.total).put("msg", ListState.msg).toString()

        @JavascriptInterface fun openList(): Long {
            rd?.close()
            val f = File(filesDir, "list.m3u")
            rd = f.bufferedReader()
            return f.length()
        }

        @JavascriptInterface fun nextChunk(): String {
            val r = rd ?: return ""
            val sb = StringBuilder()
            var last = ""
            while (sb.length < 2000000) {
                val l = r.readLine() ?: break
                sb.append(l).append('\n')
                last = l
            }
            if (last.startsWith("#EXTINF")) r.readLine()?.let { sb.append(it).append('\n') }
            if (sb.isEmpty()) { r.close(); rd = null }
            return sb.toString()
        }

        // ---- cortes em segundo plano ----
        @JavascriptInterface fun startCuts(url: String, name: String, len: Int, mode: String) {
            if (CutState.running) return
            CutState.running = true; CutState.cancel = false; CutState.total = 0; CutState.pct = 0
            CutState.msg = "Iniciando..."; CutState.error = ""
            synchronized(CutState.parts) { CutState.parts.clear() }
            val i = Intent(this@MainActivity, CutService::class.java)
                .putExtra("url", url).putExtra("name", name).putExtra("len", len).putExtra("mode", mode)
            runOnUiThread { startForegroundService(i) }
        }

        @JavascriptInterface fun cancelCuts() {
            runOnUiThread { startService(Intent(this@MainActivity, CutService::class.java).setAction("cancel")) }
        }

        @JavascriptInterface fun cutStatus(since: Int): String {
            val o = JSONObject()
            o.put("running", CutState.running).put("total", CutState.total).put("pct", CutState.pct)
                .put("msg", CutState.msg).put("error", CutState.error)
            val arr = JSONArray()
            synchronized(CutState.parts) {
                o.put("done", CutState.parts.size)
                for (i in since until CutState.parts.size) {
                    val p = CutState.parts[i]
                    arr.put(JSONObject().put("n", p.n).put("uri", p.uri).put("thumb", p.thumb))
                }
            }
            return o.put("parts", arr).toString()
        }

        @JavascriptInterface fun openVideo(uri: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (e: Exception) {}
            }
        }

        // ---- salvar arquivos vindos da página ----
        @JavascriptInterface fun saveStart(name: String, mime: String) {
            out?.close()
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LionFlix")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            out = contentResolver.openOutputStream(uri)
        }
        @JavascriptInterface fun saveChunk(b64: String) { out?.write(Base64.decode(b64, Base64.DEFAULT)) }
        @JavascriptInterface fun saveEnd() { out?.close(); out = null }
    }
}
