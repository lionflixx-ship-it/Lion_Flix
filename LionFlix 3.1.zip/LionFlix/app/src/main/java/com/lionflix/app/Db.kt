package com.lionflix.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Db {
    private var inst: SQLiteDatabase? = null

    @Synchronized
    fun db(ctx: Context): SQLiteDatabase {
        val cur = inst
        if (cur != null && cur.isOpen) return cur
        val d = SQLiteDatabase.openOrCreateDatabase(File(ctx.filesDir, "lf.db"), null)
        d.enableWriteAheadLogging()
        d.execSQL("CREATE TABLE IF NOT EXISTS it(id INTEGER PRIMARY KEY AUTOINCREMENT, cat TEXT, name TEXT, logo TEXT, url TEXT, st TEXT, s INTEGER, e INTEGER)")
        d.execSQL("CREATE INDEX IF NOT EXISTS i_cat ON it(cat)")
        d.execSQL("CREATE INDEX IF NOT EXISTS i_st ON it(st)")
        inst = d
        return d
    }

    private val serieRe = Regex("(?i)s\\d{1,2}\\s*[ex]\\s*\\d{1,3}")
    private val serieParse = Regex("(?i)^(.*?)[\\s\\-\\u2013_.]*S(\\d{1,2})\\s*[ex]\\s*(\\d{1,3})")
    private val gSerie = Regex("s[eé]rie|novela|anime")
    private val gFilme = Regex("filme|movie|vod|cine|lan[cç]amento")
    private val gInf = Regex("infantil|kids|desenho|cartoon|crian")
    private val gEsp = Regex("esporte|sport|futebol|premiere|combate|ufc|nba|espn|sportv")
    private val gcache = HashMap<String, String>()

    private fun gcat(g: String): String {
        val c = gcache[g]
        if (c != null) return c
        val x = g.lowercase()
        val r = when {
            gSerie.containsMatchIn(x) -> "Séries"
            gFilme.containsMatchIn(x) -> "Filmes"
            gInf.containsMatchIn(x) -> "Infantil"
            gEsp.containsMatchIn(x) -> "Esportes"
            else -> ""
        }
        gcache[g] = r
        return r
    }

    private fun cls(name: String, group: String, url: String): String {
        if (url.contains("/series/") || serieRe.containsMatchIn(name)) return "Séries"
        val g = gcat(group)
        if (g == "Séries") return "Séries"
        if (url.contains("/movie/") || g == "Filmes") return "Filmes"
        if (g == "Infantil" || g == "Esportes") return g
        if (gEsp.containsMatchIn(name.lowercase())) return "Esportes"
        return "Canais"
    }

    private fun attr(l: String, k: String): String {
        val i = l.indexOf(k + "=\"")
        if (i < 0) return ""
        val b = i + k.length + 2
        val e = l.indexOf('"', b)
        return if (e < 0) "" else l.substring(b, e)
    }

    /** Lê a lista M3U e grava tudo no banco do aparelho (troca o conteúdo antigo de uma vez). */
    fun importar(ctx: Context, f: File, onProgress: (Long) -> Unit): Int {
        val d = db(ctx)
        var n = 0
        d.beginTransaction()
        try {
            d.execSQL("DELETE FROM it")
            val st = d.compileStatement("INSERT INTO it(cat,name,logo,url,st,s,e) VALUES(?,?,?,?,?,?,?)")
            var name = ""
            var logo = ""
            var group = ""
            var has = false
            var pos = 0L
            var cnt = 0
            f.bufferedReader().use { r ->
                while (true) {
                    val raw = r.readLine() ?: break
                    pos += raw.length + 1L
                    cnt++
                    if (cnt % 20000 == 0) onProgress(pos)
                    val l = raw.trim()
                    if (l.isEmpty()) continue
                    if (l[0] == '#') {
                        if (l.startsWith("#EXTINF")) {
                            val c = l.lastIndexOf(',')
                            name = if (c >= 0) l.substring(c + 1).trim() else ""
                            if (name.isEmpty()) {
                                name = attr(l, "tvg-name")
                                if (name.isEmpty()) name = "Sem nome"
                            }
                            logo = attr(l, "tvg-logo")
                            group = attr(l, "group-title")
                            has = true
                        }
                    } else if (has) {
                        val cat = cls(name, group, l)
                        var t = name
                        var s = 1
                        var e = 0
                        if (cat == "Séries") {
                            val m = serieParse.find(name)
                            if (m != null) {
                                t = m.groupValues[1].trim()
                                if (t.isEmpty()) t = name
                                s = m.groupValues[2].toInt()
                                e = m.groupValues[3].toInt()
                            }
                        }
                        st.bindString(1, cat)
                        st.bindString(2, name)
                        st.bindString(3, logo)
                        st.bindString(4, l)
                        st.bindString(5, t)
                        st.bindLong(6, s.toLong())
                        st.bindLong(7, e.toLong())
                        st.executeInsert()
                        n++
                        has = false
                    }
                }
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
        return n
    }

    fun counts(ctx: Context): String {
        val o = JSONObject()
        val c = db(ctx).rawQuery("SELECT cat, COUNT(*) FROM it GROUP BY cat", null)
        c.use { while (it.moveToNext()) o.put(it.getString(0), it.getInt(1)) }
        return o.toString()
    }

    private fun like(q: String): String = "%" + q.replace("%", "").replace("_", "") + "%"

    fun query(ctx: Context, cat: String, q: String, off: Int, lim: Int): String {
        val arr = JSONArray()
        val c = db(ctx).rawQuery(
            "SELECT name, logo, url FROM it WHERE cat=? AND name LIKE ? ORDER BY id LIMIT $lim OFFSET $off",
            arrayOf(cat, like(q))
        )
        c.use {
            while (it.moveToNext()) {
                arr.put(JSONObject().put("n", it.getString(0)).put("l", it.getString(1)).put("u", it.getString(2)))
            }
        }
        return arr.toString()
    }

    fun seriesList(ctx: Context, q: String, off: Int, lim: Int): String {
        val arr = JSONArray()
        val c = db(ctx).rawQuery(
            "SELECT st, COUNT(*), MAX(logo) FROM it WHERE cat='Séries' AND st LIKE ? GROUP BY st ORDER BY MIN(id) LIMIT $lim OFFSET $off",
            arrayOf(like(q))
        )
        c.use {
            while (it.moveToNext()) {
                arr.put(JSONObject().put("t", it.getString(0)).put("c", it.getInt(1)).put("l", it.getString(2)))
            }
        }
        return arr.toString()
    }

    fun episodes(ctx: Context, st: String): String {
        val arr = JSONArray()
        val c = db(ctx).rawQuery(
            "SELECT name, url, s, e FROM it WHERE cat='Séries' AND st=? ORDER BY s, e, id",
            arrayOf(st)
        )
        c.use {
            while (it.moveToNext()) {
                arr.put(JSONObject().put("n", it.getString(0)).put("u", it.getString(1)).put("s", it.getInt(2)).put("e", it.getInt(3)))
            }
        }
        return arr.toString()
    }
}
